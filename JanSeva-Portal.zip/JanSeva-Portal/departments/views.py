"""
departments.views
~~~~~~~~~~~~~~~~~
Handles departments, complaints, and public transparency.
Uses class-based views for clean, maintainable code.
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import ListView, DetailView, CreateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib import messages
from django.urls import reverse_lazy
from django.db.models import Q, Count, Avg, F
from django.utils import timezone
from datetime import timedelta

from .models import Organization, Complaint, Review
from .forms import (
    ComplaintForm,
    ReviewForm,
    ComplaintStatusUpdateForm,
    EditComplaintForm,
    EditReviewForm,
)
from users.decorators import citizen_required, staff_required
from users.models import User


# ==========================================================
# MIXINS FOR ROLE-BASED ACCESS
# ==========================================================


class CitizenRequiredMixin(LoginRequiredMixin):
    """Mixin to ensure only verified citizens can access the view."""

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return self.handle_no_permission()
        if not request.user.is_verified:
            messages.error(
                request, "Your account must be verified to access this page."
            )
            return redirect("citizen_dashboard")
        if request.user.role != User.CITIZEN:
            messages.error(request, "This page is only accessible to citizens.")
            return redirect("citizen_dashboard")
        return super().dispatch(request, *args, **kwargs)


class StaffRequiredMixin(LoginRequiredMixin):
    """Mixin to ensure only verified staff can access the view."""

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return self.handle_no_permission()
        if not request.user.is_verified:
            messages.error(
                request, "Your account must be verified to access this page."
            )
            return redirect("staff_dashboard")
        if request.user.role != User.STAFF:
            messages.error(request, "This page is only accessible to staff.")
            return redirect("staff_dashboard")
        return super().dispatch(request, *args, **kwargs)


# ==========================================================
# PUBLIC TRANSPARENCY VIEWS
# ==========================================================


class DepartmentListView(ListView):
    """
    Public view showing all departments.
    Transparency compliance: All citizens can view departments.
    """

    model = Organization
    template_name = "departments/department_list.html"
    context_object_name = "departments"
    ordering = ["name"]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Add complaint count per department
        context["departments"] = context["departments"].annotate(
            complaint_count=Count("complaints")
        )
        return context


class DepartmentDetailView(DetailView):
    """
    Public view showing department details and related complaints.
    Transparency compliance: All citizens can view department info.
    """

    model = Organization
    template_name = "departments/department_detail.html"
    context_object_name = "department"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Get complaints for this department
        context["complaints"] = (
            self.object.complaints.all()
            .select_related("citizen")
            .prefetch_related("organizations")
            .order_by("-created_at")[:10]
        )
        # Statistics
        context["total_complaints"] = self.object.complaints.count()
        context["resolved_complaints"] = self.object.complaints.filter(
            status=Complaint.RESOLVED
        ).count()
        context["pending_complaints"] = self.object.complaints.filter(
            status=Complaint.PENDING
        ).count()
        return context


class ComplaintListView(ListView):
    """
    Public view showing all complaints with search and filter.
    Transparency compliance: All complaints are public.
    Supports pagination, search, and status/department filtering.
    """

    model = Complaint
    template_name = "departments/complaint_list.html"
    context_object_name = "complaints"
    paginate_by = 10
    ordering = ["-created_at"]

    def get_queryset(self):
        queryset = (
            super()
            .get_queryset()
            .select_related("citizen")
            .prefetch_related("organizations")
        )

        # Search functionality
        search_query = self.request.GET.get("search", "")
        if search_query:
            queryset = queryset.filter(
                Q(title__icontains=search_query)
                | Q(description__icontains=search_query)
                | Q(complaint_number__icontains=search_query)
            )

        # Filter by status
        status_filter = self.request.GET.get("status", "")
        if status_filter:
            queryset = queryset.filter(status=status_filter)

        # Filter by department
        department_filter = self.request.GET.get("department", "")
        if department_filter:
            queryset = queryset.filter(organizations__id=department_filter)

        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["search_query"] = self.request.GET.get("search", "")
        context["status_filter"] = self.request.GET.get("status", "")
        context["department_filter"] = self.request.GET.get("department", "")
        context["departments"] = Organization.objects.all().order_by("name")
        context["status_choices"] = Complaint.STATUS_CHOICES
        return context


class ComplaintDetailView(DetailView):
    """
    Public view showing detailed complaint information.
    Transparency compliance: All complaint details are public.
    """

    model = Complaint
    template_name = "departments/complaint_detail.html"
    context_object_name = "complaint"

    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .select_related("citizen", "citizen__address")
            .prefetch_related("organizations")
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Check if review exists
        try:
            context["review"] = self.object.review
        except Review.DoesNotExist:
            context["review"] = None

        # Check if current user can add review
        if self.request.user.is_authenticated:
            context["can_add_review"] = (
                self.object.citizen == self.request.user
                and self.object.status == Complaint.RESOLVED
                and not hasattr(self.object, "review")
            )
        else:
            context["can_add_review"] = False

        return context


class AnalyticsView(ListView):
    """
    Public analytics dashboard showing system-wide statistics.
    Transparency compliance: All data is public for accountability.
    Uses Django ORM aggregation and passes data to Chart.js.
    """

    model = Complaint
    template_name = "departments/analytics.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # Status distribution
        status_data = (
            Complaint.objects.values("status")
            .annotate(count=Count("id"))
            .order_by("status")
        )
        context["status_data"] = list(status_data)

        # Complaints per department
        departments = Organization.objects.annotate(
            complaint_count=Count("complaints")
        ).order_by("-complaint_count")

        department_data = [
            {"name": dept.get_name_display(), "complaint_count": dept.complaint_count}
            for dept in departments
        ]
        context["department_data"] = department_data

        # Monthly trend (last 6 months) - SQLite compatible
        six_months_ago = timezone.now() - timedelta(days=180)
        from django.db.models.functions import TruncMonth

        monthly_data = (
            Complaint.objects.filter(created_at__gte=six_months_ago)
            .annotate(month=TruncMonth("created_at"))
            .values("month")
            .annotate(count=Count("id"))
            .order_by("month")
        )

        # Format month for display
        monthly_formatted = [
            {"month": item["month"].strftime("%Y-%m"), "count": item["count"]}
            for item in monthly_data
        ]
        context["monthly_data"] = monthly_formatted

        # Average resolution time (in days)
        resolved_complaints = Complaint.objects.filter(
            status=Complaint.RESOLVED, resolved_at__isnull=False
        )
        if resolved_complaints.exists():
            avg_resolution_seconds = resolved_complaints.aggregate(
                avg_time=Avg(F("resolved_at") - F("created_at"))
            )["avg_time"]
            if avg_resolution_seconds:
                context["avg_resolution_days"] = avg_resolution_seconds.days
            else:
                context["avg_resolution_days"] = 0
        else:
            context["avg_resolution_days"] = 0

        # Average rating
        avg_rating = Review.objects.aggregate(avg_rating=Avg("rating"))["avg_rating"]
        context["avg_rating"] = round(avg_rating, 2) if avg_rating else 0

        # Overall statistics
        context["total_complaints"] = Complaint.objects.count()
        context["resolved_count"] = Complaint.objects.filter(
            status=Complaint.RESOLVED
        ).count()
        context["pending_count"] = Complaint.objects.filter(
            status=Complaint.PENDING
        ).count()
        context["in_progress_count"] = Complaint.objects.filter(
            status=Complaint.IN_PROGRESS
        ).count()
        context["total_reviews"] = Review.objects.count()

        return context


# ==========================================================
# CITIZEN ACTIONS (Verified Only)
# ==========================================================


class CreateComplaintView(CitizenRequiredMixin, CreateView):
    """
    Citizen can create a new complaint.
    Only verified citizens can access this view.
    """

    model = Complaint
    form_class = ComplaintForm
    template_name = "departments/create_complaint.html"
    success_url = reverse_lazy("my_complaints")

    def form_valid(self, form):
        form.instance.citizen = self.request.user
        messages.success(
            self.request,
            "Your complaint has been submitted successfully! You will be notified of updates.",
        )
        return super().form_valid(form)


class MyComplaintsView(CitizenRequiredMixin, ListView):
    """
    Citizen's private dashboard showing their own complaints.
    """

    model = Complaint
    template_name = "departments/my_complaints.html"
    context_object_name = "complaints"
    paginate_by = 10
    ordering = ["-created_at"]

    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .filter(citizen=self.request.user)
            .select_related("citizen")
            .prefetch_related("organizations")
        )


@citizen_required
def add_review(request, complaint_id):
    complaint = get_object_or_404(Complaint, pk=complaint_id, citizen=request.user)

    if complaint.status != Complaint.RESOLVED:
        messages.error(request, "You can only review resolved complaints.")
        return redirect("complaint_detail", pk=complaint.pk)

    if hasattr(complaint, "review"):
        messages.info(
            request, "You have already submitted a review for this complaint."
        )
        return redirect("complaint_detail", pk=complaint.pk)

    if request.method == "POST":
        form = ReviewForm(request.POST)
        form.instance.complaint = complaint
        form.instance.given_by = request.user

        if form.is_valid():
            form.save()
            messages.success(request, "Review submitted successfully.")
            return redirect("complaint_detail", pk=complaint.pk)
    else:
        form = ReviewForm()

    return render(
        request,
        "departments/add_review.html",
        {"form": form, "complaint": complaint},
    )


# ==========================================================
# STAFF ACTIONS (Verified Only)
# ==========================================================


@staff_required
def update_complaint_status(request, pk):
    """
    Staff can update complaint status.
    Only verified staff can access this view.
    """
    complaint = get_object_or_404(Complaint, pk=pk)

    if request.method == "POST":
        form = ComplaintStatusUpdateForm(request.POST, instance=complaint)
        if form.is_valid():
            form.save()
            messages.success(
                request,
                f"Complaint {complaint.complaint_number} status updated successfully!",
            )
            return redirect("complaint_detail", pk=complaint.pk)
    else:
        form = ComplaintStatusUpdateForm(instance=complaint)

    return render(
        request,
        "departments/update_status.html",
        {"form": form, "complaint": complaint},
    )


@citizen_required
def edit_complaint(request, pk):
    """
    Allow citizen to edit their own complaint.
    Only the complaint owner (citizen) can edit.
    """
    complaint = get_object_or_404(Complaint, pk=pk)

    if complaint.citizen != request.user or complaint.status != Complaint.PENDING:
        messages.error(
            request,
            "You can only edit your own pending complaints. Once a complaint is in progress or resolved, it cannot be edited. Create a new complaint if you have additional issues to report.",
        )
        return redirect("complaint_detail", pk=complaint.pk)

    # Check if user is the owner
    if complaint.citizen != request.user:
        messages.error(request, "You can only edit your own complaints.")
        return redirect("complaint_detail", pk=complaint.pk)

    if request.method == "POST":
        form = EditComplaintForm(request.POST, instance=complaint)
        if form.is_valid():
            form.save()
            messages.success(
                request,
                f"Complaint {complaint.complaint_number} updated successfully!",
            )
            return redirect("complaint_detail", pk=complaint.pk)
    else:
        form = EditComplaintForm(instance=complaint)

    return render(
        request,
        "departments/edit_complaint.html",
        {"form": form, "complaint": complaint},
    )


@citizen_required
def edit_review(request, complaint_id):
    """
    Allow citizen to edit their own review.
    Only the review owner (citizen who created it) can edit.
    """
    complaint = get_object_or_404(Complaint, pk=complaint_id)
    review = get_object_or_404(Review, complaint=complaint)

    if complaint.citizen != request.user or complaint.status != Complaint.RESOLVED:
        messages.error(
            request, "You can only edit reviews for your own resolved complaints."
        )
        return redirect("complaint_detail", pk=complaint.pk)

    # Check if user is the review owner
    if review.given_by != request.user:
        messages.error(request, "You can only edit your own reviews.")
        return redirect("complaint_detail", pk=complaint.pk)

    if request.method == "POST":
        form = EditReviewForm(request.POST, instance=review)
        if form.is_valid():
            form.save()
            messages.success(request, "Review updated successfully!")
            return redirect("complaint_detail", pk=complaint.pk)
    else:
        form = EditReviewForm(instance=review)

    return render(
        request,
        "departments/edit_review.html",
        {"form": form, "complaint": complaint, "review": review},
    )
