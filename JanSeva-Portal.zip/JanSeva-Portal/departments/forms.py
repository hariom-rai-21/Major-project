"""
departments.forms
~~~~~~~~~~~~~~~~~

ModelForms for Complaint and Review submission.
"""

from django import forms
from .models import Complaint, Review


class ComplaintForm(forms.ModelForm):
    """
    Form for creating and updating complaints.
    """

    class Meta:
        model = Complaint
        fields = ["title", "description", "organizations"]
        widgets = {
            "title": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter a clear, concise title for your complaint",
                }
            ),
            "description": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 6,
                    "placeholder": "Describe your complaint in detail...",
                }
            ),
            "organizations": forms.CheckboxSelectMultiple(),
        }
        labels = {
            "title": "Complaint Title",
            "description": "Detailed Description",
            "organizations": "Responsible Department(s)",
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["organizations"].queryset = self.fields[
            "organizations"
        ].queryset.order_by("name")


class ReviewForm(forms.ModelForm):
    """
    Form for adding review after complaint resolution.
    """

    def __init__(self, *args, complaint=None, **kwargs):
        super().__init__(*args, **kwargs)
        self._complaint = complaint

    def save(self, commit=True):
        review = super().save(commit=False)

        if self._complaint:
            review.complaint = self._complaint

        if commit:
            review.save()

        return review

    class Meta:
        model = Review
        fields = ["rating", "feedback"]
        widgets = {
            "rating": forms.RadioSelect(
                attrs={"class": "form-check-input"},
            ),
            "feedback": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 4,
                    "placeholder": "Share your experience (optional)...",
                }
            ),
        }
        labels = {
            "rating": "Rate your experience",
            "feedback": "Feedback (Optional)",
        }


class EditComplaintForm(forms.ModelForm):
    """
    Form for citizens to edit their own complaints.
    Only allows editing title and description (not organizations after creation).
    """

    class Meta:
        model = Complaint
        fields = ["title", "description"]
        widgets = {
            "title": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter a clear, concise title for your complaint",
                }
            ),
            "description": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 6,
                    "placeholder": "Describe your complaint in detail...",
                }
            ),
        }
        labels = {
            "title": "Complaint Title",
            "description": "Detailed Description",
        }


class EditReviewForm(forms.ModelForm):
    """
    Form for citizens to edit their own reviews.
    """

    class Meta:
        model = Review
        fields = ["rating", "feedback"]
        widgets = {
            "rating": forms.RadioSelect(
                attrs={"class": "form-check-input"},
            ),
            "feedback": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "rows": 4,
                    "placeholder": "Share your experience (optional)...",
                }
            ),
        }
        labels = {
            "rating": "Rate your experience",
            "feedback": "Feedback (Optional)",
        }


class ComplaintStatusUpdateForm(forms.ModelForm):
    """
    Form for staff to update complaint status.
    """

    class Meta:
        model = Complaint
        fields = ["status"]
        widgets = {
            "status": forms.Select(
                attrs={
                    "class": "form-select",
                }
            ),
        }
        labels = {
            "status": "Update Status",
        }
