"""
departments.urls
~~~~~~~~~~~~~~~~

URL configuration for departments app.
Routes organized by access level: public, citizen, staff.
"""

from django.urls import path
from . import views

urlpatterns = [
    # PUBLIC TRANSPARENCY ROUTES
    path("", views.DepartmentListView.as_view(), name="department_list"),
    path("<int:pk>/", views.DepartmentDetailView.as_view(), name="department_detail"),
    path("complaints/", views.ComplaintListView.as_view(), name="all_complaints"),
    path(
        "complaints/<int:pk>/",
        views.ComplaintDetailView.as_view(),
        name="complaint_detail",
    ),
    path("analytics/", views.AnalyticsView.as_view(), name="analytics"),
    # CITIZEN ROUTES
    path(
        "complaints/create/",
        views.CreateComplaintView.as_view(),
        name="create_complaint",
    ),
    path("complaints/my/", views.MyComplaintsView.as_view(), name="my_complaints"),
    path(
        "complaints/<int:complaint_id>/add-review/", views.add_review, name="add_review"
    ),
    path(
        "complaints/<int:pk>/edit/", views.edit_complaint, name="edit_complaint"
    ),
    path(
        "complaints/<int:complaint_id>/edit-review/", views.edit_review, name="edit_review"
    ),
    # STAFF ROUTES
    path(
        "complaints/<int:pk>/update/",
        views.update_complaint_status,
        name="update_status",
    ),
]
