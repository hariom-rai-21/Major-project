"""
departments.admin
~~~~~~~~~~~~~~~~~

Admin configuration for Organization, Complaint,
and Review models.
"""

from django.contrib import admin
from .models import Organization, Complaint, Review


# =========================================================
# Organization Admin
# =========================================================
@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    """Basic admin configuration for Organization model."""

    list_display = ("name", "created_at")
    search_fields = ("name",)
    ordering = ("name",)


# =========================================================
# Complaint Admin
# =========================================================
@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    """Admin configuration for Complaint model."""

    list_display = (
        "complaint_number",
        "title",
        "citizen",
        "status",
        "created_at",
        "resolved_at",
    )

    list_filter = ("status", "created_at", "organizations")
    search_fields = ("complaint_number", "title", "citizen__email")
    ordering = ("-created_at",)
    filter_horizontal = ("organizations",)
    readonly_fields = ("complaint_number", "created_at", "updated_at", "resolved_at")


# =========================================================
# Review Admin
# =========================================================
@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    """Admin configuration for Review model."""

    list_display = ("complaint", "given_by", "rating", "created_at")
    list_filter = ("rating", "created_at")
    search_fields = ("complaint__complaint_number", "given_by__email")
    ordering = ("-created_at",)


# =========================================================
# Customizing layout
# =========================================================
admin.site.site_header = "JanSeva Portal Administration"
admin.site.site_title = "JanSeva Portal Admin"
admin.site.index_title = "Admin Dashboard"
