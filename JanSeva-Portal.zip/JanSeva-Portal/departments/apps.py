"""
departments.apps
~~~~~~~~~~~~~~~~

App configuration for the departments application.
"""

from django.apps import AppConfig


class DepartmentsConfig(AppConfig):
    """Configuration class for the departments app."""

    name = "departments"
