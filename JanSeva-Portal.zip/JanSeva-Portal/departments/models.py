"""
departments.models
~~~~~~~~~~~~~~~~~~

Models for handling departments, complaints, and reviews.
"""

from django.db import models
from django.conf import settings
from django.utils import timezone
from django.core.exceptions import ValidationError


# =========================================================
# Organization Model
# =========================================================
class Organization(models.Model):
    """
    Represents a government department or civic authority.
    """

    HEALTH = "HEALTH"
    PWD = "PWD"
    MUNICIPAL = "MUNICIPAL"
    JAL_NIGAM = "JAL_NIGAM"
    ELECTRICITY = "ELECTRICITY"
    EDUCATION = "EDUCATION"
    TRANSPORT = "TRANSPORT"
    SWACHH = "SWACHH"
    URBAN_DEV = "URBAN_DEV"

    ORGANIZATION_CHOICES = [
        (HEALTH, "Health Department"),
        (PWD, "Public Works Department (PWD)"),
        (MUNICIPAL, "Municipal Corporation"),
        (JAL_NIGAM, "Jal Nigam"),
        (ELECTRICITY, "Electricity Board"),
        (EDUCATION, "Education Department"),
        (TRANSPORT, "Transport Authority"),
        (SWACHH, "Swachh Bharat Cell"),
        (URBAN_DEV, "Urban Development Authority"),
    ]

    name = models.CharField(
        max_length=50,
        choices=ORGANIZATION_CHOICES,
        unique=True,
    )

    description = models.TextField(blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.get_name_display()


# =========================================================
# Complaint Model
# =========================================================
class Complaint(models.Model):
    """
    Stores complaints filed by citizens.
    """

    PENDING = "P"
    IN_PROGRESS = "IP"
    RESOLVED = "R"
    REJECTED = "RJ"

    STATUS_CHOICES = [
        (PENDING, "Pending"),
        (IN_PROGRESS, "In Progress"),
        (RESOLVED, "Resolved"),
        (REJECTED, "Rejected"),
    ]

    title = models.CharField(max_length=255)
    description = models.TextField()

    citizen = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="complaints",
    )

    organizations = models.ManyToManyField(
        Organization,
        related_name="complaints",
        help_text="Select one or more responsible departments.",
    )

    status = models.CharField(
        max_length=2,
        choices=STATUS_CHOICES,
        default=PENDING,
        db_index=True,
    )

    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)

    resolved_at = models.DateTimeField(blank=True, null=True)

    complaint_number = models.CharField(
        max_length=20,
        unique=True,
        blank=True,
        null=True,
        editable=False,
    )

    def save(self, *args, **kwargs):
        """
        Custom save logic:
        - Automatically manage resolved_at based on status.
        - Generate complaint_number after first save.
        """

        # Handle resolution timestamp logic
        if self.status == self.RESOLVED:
            if self.resolved_at is None:
                self.resolved_at = timezone.now()
        else:
            self.resolved_at = None

        is_new = self.pk is None
        super().save(*args, **kwargs)

        # Generate complaint number only once
        if is_new and not self.complaint_number:
            self.complaint_number = f"CMP{self.created_at:%Y%m%d}{self.pk}"
            super().save(update_fields=["complaint_number"])

    @property
    def resolution_time(self):
        """
        Returns the time taken to resolve the complaint.
        """
        if self.resolved_at:
            return self.resolved_at - self.created_at
        return None

    def __str__(self):
        return f"{self.complaint_number or 'New Complaint'} - {self.citizen.email}"


# =========================================================
# Review Model
# =========================================================
class Review(models.Model):
    """
    Citizen review after complaint resolution.
    Rating must be natural number between 1 and 5.
    """

    RATING_CHOICES = [
        (1, "1 - Very Poor"),
        (2, "2 - Poor"),
        (3, "3 - Average"),
        (4, "4 - Good"),
        (5, "5 - Excellent"),
    ]

    given_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="reviews",
    )

    complaint = models.OneToOneField(
        Complaint,
        on_delete=models.CASCADE,
        related_name="review",
    )

    rating = models.IntegerField(
        choices=RATING_CHOICES,
        default=5,
        help_text="Citizen rating after resolution (1-5).",
    )

    feedback = models.TextField(blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    def clean(self):
        """
        Ensure review is only allowed for resolved complaints.
        """
        if not self.complaint:
            return

        if self.complaint.status != Complaint.RESOLVED:
            raise ValidationError(
                "Review can only be submitted for resolved complaints."
            )


    def __str__(self):
        return f"Review ({self.rating}) - {self.complaint.complaint_number}"

