# Create data base

```
.\_scripts\clean_database.ps1
```

# Demo Production (error page)

```
.\_scripts\demo_production.ps1
```

# Run

```
.\_scripts\run.ps1
```