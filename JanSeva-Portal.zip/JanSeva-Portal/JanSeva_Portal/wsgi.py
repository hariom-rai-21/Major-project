"""
JanSeva_Portal.wsgi
~~~~~~~~~~~~~~~~~~~

WSGI configuration for JanSeva_Portal.

Exposes the WSGI application callable as `application`.
"""

import os
from django.core.wsgi import get_wsgi_application


os.environ.setdefault("DJANGO_SETTINGS_MODULE", "JanSeva_Portal.settings")

application = get_wsgi_application()
