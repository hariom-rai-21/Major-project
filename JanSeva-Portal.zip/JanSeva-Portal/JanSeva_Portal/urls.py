"""
JanSeva_Portal.urls
~~~~~~~~~~~~~~~~~~~

Root URL configuration for JanSeva_Portal.

Defines top-level URL patterns for the project.
"""

from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from .views import index_view, current_time_api

urlpatterns = [
    path("admin/", admin.site.urls, name="admin_index"),
    path("", index_view, name="index"),
    path("api/time/", current_time_api, name="current_time_api"),
    path("users/", include("users.urls")),
    path("departments/", include("departments.urls")),
]

if not settings.DEBUG:
    handler400 = "JanSeva_Portal.views.custom_400_view"
    handler403 = "JanSeva_Portal.views.custom_403_view"
    handler404 = "JanSeva_Portal.views.custom_404_view"
    handler500 = "JanSeva_Portal.views.custom_500_view"

