"""
JanSeva_Portal.views
~~~~~~~~~~~~~~~~~~~~

Views for JanSeva_Portal.
"""

from django.shortcuts import render
from django.http import JsonResponse
from django.utils import timezone


def index_view(request):
    """Index view for the jan seva portal."""
    return render(request, "index.html")


def current_time_api(request):
    """API endpoint to get the current server time."""
    return JsonResponse({"current_time": timezone.now().isoformat()})


def custom_400_view(request, exception=None):
    """Handle HTTP 400 responses."""
    return render(request, "errors/400.html", status=400)


def custom_403_view(request, exception=None):
    """Handle HTTP 403 responses."""
    return render(request, "errors/403.html", status=403)


def custom_404_view(request, exception=None):
    """Handle HTTP 404 responses."""
    return render(request, "errors/404.html", status=404)


def custom_500_view(request):
    """Handle HTTP 500 responses."""
    return render(request, "errors/500.html", status=500)
