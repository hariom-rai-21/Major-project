"""
JanSeva_Portal.asgi
~~~~~~~~~~~~~~~~~~~

ASGI configuration for JanSeva_Portal.

Exposes the ASGI application callable as `application`.
"""

import os
from django.core.asgi import get_asgi_application


os.environ.setdefault("DJANGO_SETTINGS_MODULE", "JanSeva_Portal.settings")

application = get_asgi_application()
