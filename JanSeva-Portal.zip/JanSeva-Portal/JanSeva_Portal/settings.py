"""
JanSeva_Portal.settings
~~~~~~~~~~~~~~~~~~~~~~~

Central configuration module for the Django JanSeva_Portal project.

This file defines:
- Core security and environment-based settings
- Installed Django applications and middleware stack
- URL and WSGI configuration
- Database selection and connection settings
- Internationalization and timezone configuration
- Static files handling
- Cache configuration
- Authentication redirects
- Logging configuration
"""

# ============================
# Imports
# ============================
from pathlib import Path
import os
import sys
import dotenv
from django.contrib.messages import constants as messages


# ============================
# Load environment variables
# ============================
dotenv.load_dotenv()


# ============================
# Base directory
# ============================
BASE_DIR = Path(__file__).resolve().parent.parent


# ============================
# Security & Environment
# ============================

# SECRET KEY (must be set in environment)
SECRET_KEY = os.getenv("SECRET_KEY")
if not SECRET_KEY:
    raise ValueError("SECRET_KEY not set in environment variables")

# DEBUG
DEBUG = os.getenv("DEBUG") == "True"

# TESTING detection
TESTING = "test" in sys.argv

# ENVIRONMENT (development / staging / production)
ENVIRONMENT = os.getenv("ENV", "production").lower()


# ============================
# Allowed Hosts
# ============================
ALLOWED_HOSTS = [host for host in os.getenv("ALLOWED_HOSTS", "").split(",") if host]


# ============================
# Application definition
# ============================
INSTALLED_APPS = [
    "departments",
    "users",
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
]


# ============================
# Middleware
# ============================
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]


# ============================
# URL & WSGI
# ============================
ROOT_URLCONF = "JanSeva_Portal.urls"
WSGI_APPLICATION = "JanSeva_Portal.wsgi.application"


# ============================
# Production Security Settings
# ============================
if ENVIRONMENT == "production" and not DEBUG and not TESTING:
    CSRF_TRUSTED_ORIGINS = [
        origin for origin in os.getenv("CSRF_TRUSTED_ORIGINS", "").split(",") if origin
    ]

    CSRF_COOKIE_SECURE = True
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_EXPIRE_AT_BROWSER_CLOSE = True
    SESSION_SAVE_EVERY_REQUEST = True

    SECURE_BROWSER_XSS_FILTER = True
    SECURE_CONTENT_TYPE_NOSNIFF = True

    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SECURE_HSTS_PRELOAD = True

    SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
    SECURE_SSL_REDIRECT = True

    X_FRAME_OPTIONS = "DENY"


# ============================
# Database Configuration
# ============================
DB_ENGINE = os.getenv("DB_ENGINE", "sqlite")

if DB_ENGINE == "mysql":
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.mysql",
            "NAME": os.environ["DB_NAME"],
            "USER": os.environ["DB_USER"],
            "PASSWORD": os.environ["DB_PASSWORD"],
            "HOST": os.environ["DB_HOST"],
            "PORT": os.getenv("DB_PORT", "3306"),
        }
    }
else:
    DATABASES = {
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": BASE_DIR / "_data" / "db.sqlite3",
        }
    }


# ============================
# Password Validation
# ============================
AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",
    },
]


# ============================
# Templates
# ============================
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]


# ============================
# Internationalization
# ============================
LANGUAGE_CODE = "en-us"
TIME_ZONE = "Asia/Kolkata"
USE_I18N = True
USE_TZ = True


# ============================
# Django Messages for Bootstrap
# ============================

MESSAGE_TAGS = {
    messages.DEBUG: "secondary",
    messages.INFO: "info",
    messages.SUCCESS: "success",
    messages.WARNING: "warning",
    messages.ERROR: "danger",
}


# ============================
# Static Files
# ============================
STATIC_URL = "/static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
STATICFILES_STORAGE = "whitenoise.storage.CompressedManifestStaticFilesStorage"


# ============================
# Default Primary Key
# ============================
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"


# ============================
# Cache Configuration
# ============================
CACHES = {
    "default": {
        "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
        "LOCATION": "unique-janseva",
    }
}


# ============================
# Authentication Redirects
# ============================
LOGIN_URL = "/users/login/"
LOGIN_REDIRECT_URL = "/"
LOGOUT_REDIRECT_URL = "/users/login/"


# ============================
# Logging
# ============================
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
        },
    },
    "loggers": {
        "django": {
            "handlers": ["console"],
            "level": "INFO",
        },
    },
}

# ============================
# User model
# ============================
# Custom user model can be defined here if needed
AUTH_USER_MODEL = "users.User"
