"""
users.urls
~~~~~~~~~~

URL configuration for users app.
Handles authentication and role-based dashboards.
"""

from django.urls import path
from . import views

urlpatterns = [
    # Authentication
    path("login/", views.login_view, name="login"),
    path("signup/", views.signup, name="signup"),
    path("logout/", views.logout_view, name="logout"),
    # Dashboards
    path("citizen/dashboard/", views.citizen_dashboard, name="citizen_dashboard"),
    path("staff/dashboard/", views.staff_dashboard, name="staff_dashboard"),
    # Admin Controls
    path("admin/manage-users/", views.manage_users, name="manage_users"),
    path("admin/create-staff/", views.create_staff, name="create_staff"),
    path("admin/verify-users/", views.verify_users, name="verify_users"),
    path("admin/change-password/<int:user_id>/", views.admin_change_user_password, name="admin_change_password"),
    # User Controls
    path("change-password/", views.change_own_password, name="change_password"),
]
