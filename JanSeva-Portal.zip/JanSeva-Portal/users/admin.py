"""
users.admin
~~~~~~~~~~~

Admin configuration for the users application.
Provides minimal and clean admin setup for User and Address models.
"""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin

from .models import User, Address


# =========================================================
# Address Admin
# =========================================================
@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    """Basic admin configuration for Address model."""

    list_display = ("street1", "city", "state", "country", "zip_code")
    search_fields = ("street1", "city", "state", "zip_code")
    list_filter = ("country", "state")


# =========================================================
# User Admin
# =========================================================
@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """Minimal admin configuration for custom User model."""

    list_display = ("email", "username", "role", "is_verified", "is_staff", "is_active")
    list_filter = ("role", "is_verified", "is_staff", "is_active")
    search_fields = ("email", "username", "phone")
    ordering = ("email",)

    fieldsets = (
        (None, {"fields": ("email", "password")}),
        (
            "Personal Info",
            {"fields": ("username", "first_name", "last_name", "phone", "address")},
        ),
        ("Role", {"fields": ("role", "is_verified")}),
        (
            "Permissions",
            {
                "fields": (
                    "is_active",
                    "is_staff",
                    "is_superuser",
                    "groups",
                    "user_permissions",
                )
            },
        ),
        ("Important Dates", {"fields": ("last_login",)}),
    )

    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": ("email", "username", "password1", "password2", "role"),
            },
        ),
    )

# =========================================================
# Customizing layout
# =========================================================
admin.site.site_header = "JanSeva Portal Administration"
admin.site.site_title = "JanSeva Portal Admin"
admin.site.index_title = "Admin Dashboard"