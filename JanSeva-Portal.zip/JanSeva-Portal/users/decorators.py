"""
users.decorators
~~~~~~~~~~~~~~~~
Role-based decorators with verification checks.
"""

from functools import wraps
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from .models import User


def verified_required(view_func):
    """
    Ensures user is verified before accessing any protected view.
    """

    @login_required
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        """Check if the user's account is verified."""

        if not request.user.is_verified:
            raise PermissionDenied("Account not verified.")
        return view_func(request, *args, **kwargs)

    return _wrapped_view


def admin_required(view_func):
    """Allows only Admin users to access the view."""

    @verified_required
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        """Check if the user has Admin role."""
        if request.user.role != User.ADMIN:
            raise PermissionDenied("Admin access required.")
        return view_func(request, *args, **kwargs)

    return _wrapped_view


def staff_required(view_func):
    """Allows only Staff users to access the view."""

    @verified_required
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        """Check if the user has Staff role."""
        if request.user.role == User.STAFF or request.user.role == User.ADMIN:
            return view_func(request, *args, **kwargs)
        else:
            raise PermissionDenied("Staff access required.")

    return _wrapped_view


def employee_required(view_func):
    """Allows both Admin and Staff users to access the view."""

    @verified_required
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        """Check if the user has either Admin or Staff role."""
        if request.user.role not in [User.ADMIN, User.STAFF]:
            raise PermissionDenied("Employee access required.")
        return view_func(request, *args, **kwargs)

    return _wrapped_view


def citizen_required(view_func):
    """Allows only Citizen users to access the view."""

    @verified_required
    @wraps(view_func)
    def _wrapped_view(request, *args, **kwargs):
        """Check if the user has Citizen role."""
        if request.user.role != User.CITIZEN:
            raise PermissionDenied("Citizen access required.")
        return view_func(request, *args, **kwargs)

    return _wrapped_view
