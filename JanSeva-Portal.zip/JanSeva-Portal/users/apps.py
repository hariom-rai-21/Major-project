"""
users.apps
~~~~~~~~~~

App configuration for the users application.
"""

from django.apps import AppConfig


class UsersConfig(AppConfig):
    """Configuration class for the users app."""

    name = "users"
