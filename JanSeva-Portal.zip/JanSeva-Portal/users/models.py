"""
users.models
~~~~~~~~~~~~

Contains the database models for the users application.
"""

from django.db import models
from django.contrib.auth.models import AbstractUser


# =========================================================
# Address Model
# =========================================================
class Address(models.Model):
    """
    Stores address information for a user.
    """

    street1 = models.CharField(max_length=255)
    street2 = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    country = models.CharField(max_length=100, default="India")
    zip_code = models.CharField(max_length=20)

    def __str__(self):
        """String representation of the address."""
        return f"{self.street1}, {self.city}, {self.state}"


# =========================================================
# Custom User Model
# =========================================================
class User(AbstractUser):
    """
    Custom user model with role-based access.
    """

    # Role System
    ADMIN = "A"
    STAFF = "S"
    CITIZEN = "C"

    ROLE_CHOICES = [
        (ADMIN, "Admin"),
        (STAFF, "Staff"),
        (CITIZEN, "Citizen"),
    ]

    role = models.CharField(
        max_length=1,
        choices=ROLE_CHOICES,
        default=CITIZEN,
        db_index=True,
        help_text="Defines the role of the user in the system.",
    )

    phone = models.CharField(
        max_length=15, blank=True, null=True, help_text="Optional contact number."
    )

    email = models.EmailField(
        unique=True, db_index=True, help_text="Unique email used for authentication."
    )

    address = models.OneToOneField(
        Address,
        on_delete=models.SET_NULL,
        blank=True,
        null=True,
        related_name="user",
        help_text="Optional one-to-one relationship with Address.",
    )

    is_verified = models.BooleanField(
        default=False, help_text="Indicates whether the user has been verified."
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["username"]

    def save(self, *args, **kwargs):
        """Override user role for superusers."""
        if self.is_superuser:
            self.role = self.ADMIN
            self.is_verified = True
        super().save(*args, **kwargs)

    def _get_role_display(self):
        """Returns the display name of the role."""
        return dict(self.ROLE_CHOICES).get(self.role, "Unknown")

    def __str__(self):
        """String representation of the user."""
        return f"{self.email} ({self._get_role_display()})"
