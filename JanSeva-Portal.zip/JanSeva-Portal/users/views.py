"""
users.views
~~~~~~~~~~~
Authentication and role-based dashboards.
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.views.generic import CreateView, ListView
from django.urls import reverse_lazy
from django.db.models import Count, Q

from .decorators import admin_required, staff_required, citizen_required
from .forms import LoginForm, CitizenSignupForm, StaffCreationForm, AdminPasswordChangeForm, UserPasswordChangeForm
from .models import User


# ==========================================
# Public Authentication Views
# ==========================================


def login_view(request):
    """
    Login view for all users (Citizen, Staff, Admin).
    Uses email and password for authentication.
    """
    if request.user.is_authenticated:
        # Redirect already authenticated users to their appropriate dashboard
        return redirect("index")

    if request.method == "POST":
        form = LoginForm(data=request.POST)
        if form.is_valid():
            email = form.cleaned_data.get("username")  # username field contains email
            password = form.cleaned_data.get("password")
            user = authenticate(request, username=email, password=password)

            if user is not None:
                login(request, user)
                messages.success(
                    request, f"Welcome back, {user.username}! You are now logged in."
                )

                # Redirect based on role
                next_url = request.GET.get("next")
                if next_url:
                    return redirect(next_url)

                if user.role == User.CITIZEN and user.is_verified:
                    return redirect("citizen_dashboard")
                elif user.role == User.STAFF and user.is_verified:
                    return redirect("staff_dashboard")
                elif user.role == User.ADMIN and user.is_verified:
                    return redirect("create_staff")
                else:
                    return redirect("index")
            else:
                messages.error(request, "Invalid email or password.")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = LoginForm()

    return render(request, "users/login.html", {"form": form})


def signup(request):
    """
    Self-registration for citizens only.
    Accounts require admin verification before full access.
    """
    if request.user.is_authenticated:
        messages.info(request, "You are already registered and logged in.")
        return redirect("index")

    if request.method == "POST":
        form = CitizenSignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(
                request,
                f"Registration successful! Your account has been created as '{user.username}'. "
                "Please wait for admin verification before you can file complaints.",
            )
            return redirect("login")
        else:
            messages.error(request, "Please correct the errors in the form.")
    else:
        form = CitizenSignupForm()

    return render(request, "users/signup.html", {"form": form})


# ==========================================
# Logout
# ==========================================


@login_required
def logout_view(request):
    """
    Logout view for authenticated users.
    """
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect("login")


# ==========================================
# Citizen Dashboard
# ==========================================


@citizen_required
def citizen_dashboard(request):
    """
    Citizen dashboard showing overview of complaints and quick actions.
    """
    from departments.models import Complaint, Review

    # Get citizen's complaints
    complaints = Complaint.objects.filter(citizen=request.user).order_by("-created_at")

    # Statistics
    total_complaints = complaints.count()
    pending_complaints = complaints.filter(status=Complaint.PENDING).count()
    resolved_complaints = complaints.filter(status=Complaint.RESOLVED).count()
    in_progress_complaints = complaints.filter(status=Complaint.IN_PROGRESS).count()

    # Recent complaints
    recent_complaints = complaints[:5]

    # Reviews given
    reviews_count = Review.objects.filter(given_by=request.user).count()

    context = {
        "total_complaints": total_complaints,
        "pending_complaints": pending_complaints,
        "resolved_complaints": resolved_complaints,
        "in_progress_complaints": in_progress_complaints,
        "recent_complaints": recent_complaints,
        "reviews_count": reviews_count,
    }

    return render(request, "users/citizen_dashboard.html", context)


# ==========================================
# Staff Dashboard
# ==========================================


@staff_required
def staff_dashboard(request):
    """
    Staff dashboard showing all complaints and quick statistics.
    """
    from departments.models import Complaint, Organization

    # Get all complaints
    complaints = Complaint.objects.all().order_by("-created_at")

    # Statistics
    total_complaints = complaints.count()
    pending_complaints = complaints.filter(status=Complaint.PENDING).count()
    resolved_complaints = complaints.filter(status=Complaint.RESOLVED).count()
    in_progress_complaints = complaints.filter(status=Complaint.IN_PROGRESS).count()

    # Recent complaints requiring attention
    recent_complaints = complaints.filter(
        Q(status=Complaint.PENDING) | Q(status=Complaint.IN_PROGRESS)
    ).order_by("-created_at")[:10]

    # Department statistics
    total_departments = Organization.objects.count()

    context = {
        "total_complaints": total_complaints,
        "pending_complaints": pending_complaints,
        "resolved_complaints": resolved_complaints,
        "in_progress_complaints": in_progress_complaints,
        "recent_complaints": recent_complaints,
        "total_departments": total_departments,
    }

    return render(request, "users/staff_dashboard.html", context)


# ==========================================
# Admin Features
# ==========================================


@admin_required
def create_staff(request):
    """
    Admin view to create new staff users.
    """
    if request.method == "POST":
        form = StaffCreationForm(request.POST)
        if form.is_valid():
            staff_user = form.save()
            messages.success(
                request,
                f"Staff account '{staff_user.username}' created successfully! "
                f"{'Account is verified and active.' if staff_user.is_verified else 'Pending verification.'}",
            )
            return redirect("create_staff")
        else:
            messages.error(request, "Please correct the errors in the form.")
    else:
        form = StaffCreationForm()

    # Show existing staff
    staff_users = User.objects.filter(role=User.STAFF).order_by("-created_at")

    context = {
        "form": form,
        "staff_users": staff_users,
    }

    return render(request, "users/create_staff.html", context)


@admin_required
def verify_users(request):
    """
    Admin view to verify pending user accounts.
    """
    if request.method == "POST":
        user_id = request.POST.get("user_id")
        action = request.POST.get("action")

        user = get_object_or_404(User, pk=user_id)

        if action == "verify":
            user.is_verified = True
            user.save()
            messages.success(
                request, f"User '{user.username}' has been verified successfully!"
            )
        elif action == "unverify":
            user.is_verified = False
            user.save()
            messages.warning(
                request, f"User '{user.username}' verification has been revoked."
            )

        return redirect("verify_users")

    # Get all users grouped by verification status
    unverified_users = User.objects.filter(is_verified=False).order_by("-created_at")
    verified_users = User.objects.filter(is_verified=True).exclude(
        role=User.ADMIN
    ).order_by("-created_at")

    # Statistics
    total_users = User.objects.count()
    unverified_count = unverified_users.count()
    verified_count = verified_users.count()

    # Breakdown by role
    citizen_count = User.objects.filter(role=User.CITIZEN).count()
    staff_count = User.objects.filter(role=User.STAFF).count()
    admin_count = User.objects.filter(role=User.ADMIN).count()

    context = {
        "unverified_users": unverified_users,
        "verified_users": verified_users,
        "total_users": total_users,
        "unverified_count": unverified_count,
        "verified_count": verified_count,
        "citizen_count": citizen_count,
        "staff_count": staff_count,
        "admin_count": admin_count,
    }

    return render(request, "users/verify_users.html", context)


@admin_required
def manage_users(request):
    """
    Admin panel to view and manage all users.
    Shows complete list with quick actions for password change and verification.
    """
    # Get all users ordered by creation date
    all_users = User.objects.all().order_by("-created_at")

    # Statistics
    total_users = all_users.count()
    citizen_count = all_users.filter(role=User.CITIZEN).count()
    staff_count = all_users.filter(role=User.STAFF).count()
    admin_count = all_users.filter(role=User.ADMIN).count()

    context = {
        "all_users": all_users,
        "total_users": total_users,
        "citizen_count": citizen_count,
        "staff_count": staff_count,
        "admin_count": admin_count,
    }

    return render(request, "users/manage_users.html", context)


@admin_required
def admin_change_user_password(request, user_id):
    """
    Admin can change any user's password without knowing the old password.
    Admin-only functionality.
    """
    user_to_change = get_object_or_404(User, pk=user_id)

    if request.method == "POST":
        form = AdminPasswordChangeForm(request.POST)
        if form.is_valid():
            new_password = form.cleaned_data["new_password1"]
            user_to_change.set_password(new_password)
            user_to_change.save()
            messages.success(
                request,
                f"Password successfully changed for {user_to_change.username}.",
            )
            return redirect("verify_users")
    else:
        form = AdminPasswordChangeForm()

    context = {
        "form": form,
        "user_to_change": user_to_change,
    }

    return render(request, "users/admin_change_password.html", context)


@login_required
def change_own_password(request):
    """
    Users can change their own password.
    Requires old password verification.
    """
    if request.method == "POST":
        form = UserPasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            form.save()
            # Update session to prevent logout
            from django.contrib.auth import update_session_auth_hash
            update_session_auth_hash(request, form.user)
            messages.success(request, "Your password has been changed successfully!")
            return redirect("index")
    else:
        form = UserPasswordChangeForm(user=request.user)

    context = {
        "form": form,
    }

    return render(request, "users/change_password.html", context)
