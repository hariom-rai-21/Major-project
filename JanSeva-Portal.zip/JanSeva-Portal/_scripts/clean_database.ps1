$ErrorActionPreference = "Stop"

Write-Host "Cleaning up the project..."

# =====================================================
# REMOVE DATABASE
# =====================================================

if (Test-Path ".\_data\db.sqlite3") {
    Remove-Item ".\_data\db.sqlite3" -Force
    Write-Host "Removed db.sqlite3"
}

Write-Host "Running migrations..."

# =====================================================
# RUN MIGRATIONS
# =====================================================

python manage.py makemigrations
python manage.py migrate


# =====================================================
# CREATE SUPERUSER SAFELY USING DJANGO ORM
# =====================================================

Write-Host "Ensuring superuser exists..."

$email = 'admin@janseva.gov.in'
$username = 'admin'
$password = 'admin123'

python manage.py shell -c "
from django.contrib.auth import get_user_model
User = get_user_model()

email = '$email'
username = '$username'
password = '$password'

if not User.objects.filter(email=email).exists():
    User.objects.create_superuser(
        email=email,
        username=username,
        password=password
    )
    print('Superuser created successfully.')
else:
    print('Superuser already exists.')
"

# =====================================================
# LOAD DUMMY DATA
# =====================================================

Write-Host "Loading dummy data..."
Get-Content _data/dummy_data.sql | python manage.py dbshell
write-Host "Dummy data loaded successfully."

# =====================================================
# DONE
# =====================================================

Write-Host "Project cleaned and ready to go!"
Write-Host ""
Write-Host "Admin login credentials:"
Write-Host "Email: $email"
Write-Host "Username: $username"
Write-Host "Password: $password"
