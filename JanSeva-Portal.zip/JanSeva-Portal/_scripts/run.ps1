$ErrorActionPreference = "Stop"

Write-Host "Starting Django in development mode..."

# =========================
# Core
# =========================
$env:DEBUG = "True"
$env:ENV = "development"
$env:SECRET_KEY = "dev-secret-key-change-this"


# =========================
# Hosts
# =========================
$env:ALLOWED_HOSTS = "127.0.0.1,localhost"

# =========================
# Database
# =========================
$env:DB_ENGINE = "sqlite"

python manage.py runserver localhost:8000