$ErrorActionPreference = "Stop"

Write-Host "Starting Django in production-like mode..."

# =========================
# Core
# =========================
$env:DEBUG = "False"
$env:ENV = "development" # not production, but close enough for demo purposes
$env:SECRET_KEY = "dev-secret-key-change-this"


# =========================
# Hosts
# =========================
$env:ALLOWED_HOSTS = "127.0.0.1,localhost"

# =========================
# Database
# =========================
$env:DB_ENGINE = "sqlite"

python manage.py runserver localhost:8000 --insecure